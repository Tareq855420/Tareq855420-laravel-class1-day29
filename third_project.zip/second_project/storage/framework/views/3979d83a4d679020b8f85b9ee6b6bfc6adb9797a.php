<?php $__env->startSection('title'); ?>
    Full Name
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card card-body">
                        <form action="<?php echo e(route('get-full-name')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="" class="col-md-4 col-form-label">First Name</label>
                                <div class="col-md-8">
                                    <input type="text" name="first_name" class="form-control">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-4 col-form-label">Last Name</label>
                                <div class="col-md-8">
                                    <input type="text" name="last_name" class="form-control">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-4 col-form-label">Result</label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" value="<?php echo e(isset($fullName) ? $fullName : ''); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-4 col-form-label"></label>
                                <div class="col-md-8">
                                    <input type="submit" class="btn btn-success btn-block" value="Get Full Name">
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tareq\second_project\resources\views/fullName/full-name.blade.php ENDPATH**/ ?>